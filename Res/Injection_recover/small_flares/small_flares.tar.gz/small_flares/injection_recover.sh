#!/bin/bash

tar -xzf CeleriteQFD.tar.gz

mkdir ./res_$1-$2
mkdir ./packages
# make sure the script will use your R installation, 
# and the working directory as its home location
export R_LIBS=$PWD/packages

# run your script
Rscript ./CeleriteQFD/tests/injection_recovery/flare_injection_CHTC.R $1 $2

tar -czvf small_flares_$1-$2.tar.gz ./res_$1-$2


